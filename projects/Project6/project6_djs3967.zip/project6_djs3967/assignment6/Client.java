package assignment6;

public class Client {

    int client_number;

    public Client(int n){
        client_number=n;

    }

    public int getClient_number() {
        return client_number;
    }
}

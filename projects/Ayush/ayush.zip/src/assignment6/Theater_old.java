// insert header here
package assignment6;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Theater_old {





}

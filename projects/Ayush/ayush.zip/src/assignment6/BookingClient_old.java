// Insert header here

package assignment6;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Thread;



import assignment6.Theater;


public class BookingClient_old {

    List<Thread> threads = new ArrayList<>();

    public List<Thread> simulate() {


        return threads;
    }

}
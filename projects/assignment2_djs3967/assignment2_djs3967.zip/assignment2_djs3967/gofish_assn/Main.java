package gofish_assn;

public class Main {
	
	public static void main(String args[]) {



		GoFishGame a = new GoFishGame();
		a.GoFishMain();
	}

}
